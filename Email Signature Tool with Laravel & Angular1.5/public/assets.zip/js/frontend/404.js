$(function() {

    function move404() {
        $('#animate').animate({
                'left': '+=88%'
            }, 3500).delay(480)
            .animate({
                'left': '-=88%'
            }, 3500, function() {
                setTimeout(move404, 1000);
            });
    }
    move404();

});

